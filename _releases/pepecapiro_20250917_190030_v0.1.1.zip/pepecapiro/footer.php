<footer style="margin-top:40px;padding:24px 0;border-top:1px solid #eee;">
  <div style="max-width:960px;margin:0 auto;padding:0 16px;">
    <p>© <?php echo date('Y'); ?> Pepecapiro — Todos los derechos reservados.</p>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
