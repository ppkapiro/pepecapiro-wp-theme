<?php
add_action('after_setup_theme', function(){
  add_theme_support('title-tag');
  add_theme_support('post-thumbnails');
  // Carga de textdomain para i18n
  load_theme_textdomain('pepecapiro', get_template_directory() . '/languages');
  register_nav_menus([
    'primary' => __('Menú principal','pepecapiro')
  ]);
});

add_action('wp_enqueue_scripts', function(){
  // Preload de fuentes locales (si existen archivos físicos)
  $fonts = [
    'montserrat/Montserrat-SemiBold.woff2',
    'montserrat/Montserrat-Bold.woff2',
    'opensans/OpenSans-Regular.woff2',
    'opensans/OpenSans-SemiBold.woff2',
    'opensans/OpenSans-Italic.woff2',
  ];
  foreach ($fonts as $f) {
    $abs = get_template_directory().'/assets/fonts/'.$f;
    if ( file_exists($abs) ) {
      $ver = filemtime($abs);
      echo '<link rel="preload" as="font" type="font/woff2" crossorigin href="'.esc_url(get_template_directory_uri().'/assets/fonts/'.$f.'?v='.$ver).'" />' . "\n";
    }
  }

  $theme_version = wp_get_theme()->get('Version');
  $theme_dir = get_stylesheet_directory();
  $css_base = $theme_dir . '/assets/css/theme';
  $preferred = file_exists($css_base . '.min.css') ? $css_base . '.min.css' : $css_base . '.css';
  $version = $theme_version;
  if ( file_exists( $preferred ) ) {
      $version = filemtime( $preferred );
  }
  $public_path = get_stylesheet_directory_uri() . '/assets/css/' . basename($preferred);
  wp_enqueue_style('pepecapiro-theme', $public_path, [], $version);

  // Critical CSS opcional
  $critical_file = $theme_dir . '/assets/css/critical.css';
  if ( file_exists( $critical_file ) ) {
    $crit_ver = filemtime($critical_file);
    $crit_uri = get_stylesheet_directory_uri() . '/assets/css/critical.css?ver=' . $crit_ver;
    echo '<link rel="preload" as="style" href="' . esc_url($crit_uri) . '" />' . "\n";
    $css_inline = file_get_contents($critical_file);
    if ( strlen($css_inline) < 12000 ) { // salvaguarda tamaño
      echo '<style>' . wp_kses_post($css_inline) . '</style>' . "\n";
    }
  }
});

// Resource hints adicionales podrían agregarse aquí si se usan CDNs

// SEO mínimo OpenGraph / Twitter
add_action('wp_head', function(){
  if (is_admin()) return;
  $title = wp_get_document_title();
  $desc  = get_bloginfo('description');
  $url   = esc_url(home_url(add_query_arg([], $_SERVER['REQUEST_URI'] ?? '')));
  echo "\n<!-- SEO base -->\n";
  echo '<meta property="og:title" content="'.esc_attr($title).'" />' . "\n";
  echo '<meta property="og:type" content="'. (is_singular() ? 'article' : 'website') .'" />' . "\n";
  echo '<meta property="og:url" content="'.$url.'" />' . "\n";
  echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
}, 5);

// Breadcrumbs simples
function pc_breadcrumbs(){
  if (is_front_page()) return;
  echo '<nav aria-label="breadcrumb" class="container" style="font-size:14px;margin:12px 0;">';
  echo '<a href="'.esc_url(home_url('/')).'">Inicio</a> » ';
  if (is_singular('post')){
    $posts_page = get_option('page_for_posts');
    if ($posts_page) {
      echo '<a href="'.esc_url(get_permalink($posts_page)).'">Blog</a> » ';
    }
  }
  if (is_archive()){
    the_archive_title('<span>','</span>');
  } elseif (is_singular()){
    the_title('<span>','</span>');
  } elseif (is_404()) {
    echo '<span>404</span>';
  }
  echo '</nav>';
}
add_action('wp_body_open','pc_breadcrumbs');
