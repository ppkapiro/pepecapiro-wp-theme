<?php get_header(); ?>
<main class="container" style="padding:64px 0;">
  <h1 style="font-family:var(--ff-title)">Página no encontrada</h1>
  <p>Revisa el menú o vuelve al <a href="<?php echo esc_url(home_url('/')); ?>">inicio</a>.</p>
</main>
<?php get_footer(); ?>
