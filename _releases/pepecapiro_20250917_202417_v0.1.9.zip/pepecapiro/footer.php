<footer class="site-footer" style="margin-top:40px;padding:24px 0;border-top:1px solid #eee;">
  <div style="max-width:960px;margin:0 auto;padding:0 16px;display:flex;flex-direction:column;gap:8px;">
    <nav style="font-size:14px;display:flex;flex-wrap:wrap;gap:12px;">
      <a href="#" rel="nofollow">Política de privacidad</a>
      <a href="#" rel="nofollow">Términos</a>
    </nav>
    <p style="font-size:14px;margin:0;">© <?php echo date('Y'); ?> Pepecapiro</p>
  </div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
